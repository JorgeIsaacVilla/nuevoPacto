M1 Factory Preload
==================

Before you begin please note : This reload procedure will replace the contents of your M1�s memory. If you have any valuable data stored in your M1, please save it via Midi to a Midi back-up device before continuing.

You will need WinZip(tm) or a similar program to unzip the archived download file.

After un-zipping the zipped file you should have two files:

m1preld.mid

m1preld.syx

Both files contain the same M1 preload data but are in different formats. 

The file m1preld.mid is a Standard Midi File that can be loaded into most modern hardware and computer based midi sequencers (you can load it into Windows Media Player as well) Once loaded into a sequencer it can be played out via Midi to the M1 just like playing a song.

The file m1preld.syx is MIDEX format and contains the raw Midi system exclusive data (Starts F0 and ends F7). This type of file can be loaded directly into Cakewalk on the PC as well as some shareware Midi librarian programs such as Software Forge Sysex Manager 95.

Note: Korg system exclusive is channel sensitive and therefore this preload data is saved using Midi channel 1. Please ensure you set the receiving M1 to Midi channel 1.


To reload the M1
================

1. Connect the MIDI OUT socket from your PC/sequencer to the MIDI IN socket on the M1.

2. Switch on the M1 and set the basic MIDI channel to 1 (Global Midi Channel) and ensure that SYS-EX RECEIVE is enabled. (if you fail to do this, the reload procedure will not work!

3. Load the reload file into your PC/sequencer (m1preld.mid or m1preld.syx) and transmit it to the M1.

4. When all data has been transmitted switch off the M1, then switch it back on again and check that the first program sound is I00: Universe.

5. You should find that all factory sounds and demos have now been restored.



 

